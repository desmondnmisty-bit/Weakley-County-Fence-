
  # Weakley County Fence

  This is a code bundle for Weakley County Fence. The original project is available at https://www.figma.com/design/7SS1Zb54XK5TZ1hBXDvy20/Weakley-County-Fence.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  