import { Phone, Mail, MapPin, Clock } from 'lucide-react';
import { useState } from 'react';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission (mock)
    alert('Thank you for your inquiry! We will contact you shortly.');
    setFormData({ name: '', email: '', phone: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section id="contact" className="py-20 bg-gray-50" aria-labelledby="contact-heading">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 id="contact-heading" className="text-4xl mb-4">Get Your Free Estimate</h2>
          <p className="text-xl text-gray-600">
            Ready to start your fencing project? Contact Weakley County Fence today!
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div>
            <form onSubmit={handleSubmit} className="space-y-6" aria-label="Contact form for free fence estimate">
              <div>
                <label htmlFor="name" className="block mb-2">
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  aria-required="true"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                />
              </div>
              <div>
                <label htmlFor="email" className="block mb-2">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  aria-required="true"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block mb-2">
                  Phone
                </label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  aria-required="true"
                  placeholder="731-456-2500"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                />
              </div>
              <div>
                <label htmlFor="message" className="block mb-2">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  aria-required="true"
                  rows={4}
                  placeholder="Tell us about your fencing project..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                />
              </div>
              <button
                type="submit"
                className="w-full py-4 bg-[#355E3B] text-white rounded-lg hover:bg-[#2a4a2e] transition-colors"
                aria-label="Submit contact form for free estimate"
              >
                Send Message
              </button>
            </form>
          </div>

          <div className="space-y-8">
            <div className="flex items-start gap-4 bg-white p-4 rounded-lg shadow-md border-l-4 border-[#355E3B]">
              <div className="w-12 h-12 bg-[#355E3B] rounded-full flex items-center justify-center flex-shrink-0" aria-hidden="true">
                <Phone className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="mb-2">Phone</h3>
                <a href="tel:+17314562500" className="text-gray-600 hover:text-[#355E3B]">731-456-2500</a>
              </div>
            </div>

            <address className="flex items-start gap-4 bg-white p-4 rounded-lg shadow-md border-l-4 border-[#D2B48C] not-italic">
              <div className="w-12 h-12 bg-[#D2B48C] rounded-full flex items-center justify-center flex-shrink-0" aria-hidden="true">
                <MapPin className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="mb-2">Address</h3>
                <p className="text-gray-600">189 Dedham Rd</p>
                <p className="text-gray-600">Sharon, TN 38255</p>
              </div>
            </address>

            <div className="flex items-start gap-4 bg-white p-4 rounded-lg shadow-md border-l-4 border-[#355E3B]">
              <div className="w-12 h-12 bg-[#355E3B] rounded-full flex items-center justify-center flex-shrink-0" aria-hidden="true">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="mb-2">Business Hours</h3>
                <p className="text-gray-600">Monday - Friday: 7:00 AM - 6:00 PM</p>
                <p className="text-gray-600">Saturday: 8:00 AM - 4:00 PM</p>
                <p className="text-gray-600">Sunday: Closed</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}