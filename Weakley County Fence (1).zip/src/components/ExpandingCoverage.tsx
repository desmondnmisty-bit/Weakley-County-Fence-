import { TrendingUp, MapPin, Phone } from 'lucide-react';

export function ExpandingCoverage() {
  return (
    <section className="py-16 bg-gradient-to-br from-[#355E3B] to-[#2a4a2e] text-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="bg-white/20 p-4 rounded-full">
              <TrendingUp className="w-12 h-12" />
            </div>
          </div>
          <h2 className="text-4xl mb-4">Rapidly Expanding Service Area</h2>
          <p className="text-xl max-w-3xl mx-auto opacity-90">
            We're growing daily to serve more communities across Tennessee and Kentucky with professional fence installation services
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <div className="bg-white/10 backdrop-blur-sm p-8 rounded-lg border border-white/20">
            <div className="flex items-start gap-4 mb-4">
              <MapPin className="w-8 h-8 flex-shrink-0" />
              <div>
                <h3 className="text-2xl mb-3">Currently Serving</h3>
                <p className="mb-4 opacity-90">
                  7 counties across Northwest Tennessee including Weakley, Carroll, Henry, Gibson, Obion, Madison, and Dyer Counties
                </p>
                <ul className="space-y-2 text-sm opacity-90">
                  <li>✓ 50+ cities and communities</li>
                  <li>✓ Residential & commercial properties</li>
                  <li>✓ Farm and rural areas</li>
                  <li>✓ Western Kentucky border communities</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-[#D2B48C] text-black p-8 rounded-lg shadow-xl">
            <h3 className="text-2xl mb-4">Don't See Your Area Listed?</h3>
            <p className="mb-6">
              We add new service areas every day! If you don't see your city or county listed, call us anyway. 
              We're constantly expanding throughout Tennessee and Kentucky.
            </p>
            <div className="space-y-4">
              <a
                href="tel:+17314562500"
                className="flex items-center justify-center gap-3 w-full px-6 py-4 bg-[#355E3B] text-white rounded-lg hover:bg-[#2a4a2e] transition-colors"
              >
                <Phone className="w-5 h-5" />
                <div>
                  <div className="text-sm">Call to Check Availability</div>
                  <div className="font-bold text-lg">731-456-2500</div>
                </div>
              </a>
              <p className="text-sm text-center">
                Chances are, we can help with your fencing project!
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}