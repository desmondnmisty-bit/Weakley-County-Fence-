import { Facebook, Instagram, Twitter, CreditCard, Clock, Lock, Shield, Banknote, FileText, MapPin } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function Footer() {
  return (
    <footer className="bg-[#1a1a1a] text-white py-12" role="contentinfo">
      <div className="max-w-7xl mx-auto px-4">
        <nav className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-xl mb-4">Weakley County Fence</h3>
            <p className="text-gray-400 mb-4">
              Where Fences Make Great Neighbors
            </p>
            <div className="flex items-center gap-2 text-gray-400 mb-2">
              <MapPin className="w-4 h-4" />
              <address className="not-italic text-sm">
                189 Dedham Rd<br />
                Sharon, TN 38255
              </address>
            </div>
            <a 
              href="https://www.google.com/maps/dir/?api=1&destination=189+Dedham+Rd,+Sharon,+TN+38255"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#D2B48C] hover:text-white transition-colors text-sm inline-flex items-center gap-1 mt-2"
            >
              Get Directions →
            </a>
          </div>

          <div>
            <h4 className="mb-4 text-[#D2B48C]">Quick Links</h4>
            <ul className="space-y-2 text-gray-400">
              <li>
                <a href="#services" className="hover:text-[#D2B48C] transition-colors">
                  Services
                </a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-[#D2B48C] transition-colors">
                  Gallery
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-[#D2B48C] transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#D2B48C] transition-colors">
                  Contact
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 flex items-center gap-2 text-[#D2B48C]">
              <Clock className="w-5 h-5" />
              Business Hours
            </h4>
            <ul className="space-y-2 text-gray-400">
              <li>Monday - Friday: 9am - 5pm</li>
              <li>Saturday: 9am - 2pm</li>
              <li>Sunday: Closed</li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 flex items-center gap-2 text-[#D2B48C]">
              <CreditCard className="w-5 h-5" />
              Payment Methods
            </h4>
            <div className="flex items-center gap-2 flex-wrap">
              {/* Visa Logo */}
              <div className="bg-white rounded px-2 py-1 flex items-center justify-center w-12 h-8">
                <span className="font-bold text-[#1A1F71] italic text-xs">VISA</span>
              </div>
              
              {/* Mastercard Logo */}
              <div className="bg-white rounded px-2 py-1 flex items-center justify-center w-12 h-8">
                <div className="flex items-center gap-0.5">
                  <div className="w-2 h-2 rounded-full bg-[#EB001B]"></div>
                  <div className="w-2 h-2 rounded-full bg-[#FF5F00] -ml-0.5"></div>
                </div>
              </div>
              
              {/* Dollar Bill Icon */}
              <div className="bg-green-600 rounded px-2 py-1 flex items-center justify-center w-12 h-8">
                <Banknote className="w-4 h-4 text-white" />
              </div>
              
              {/* Check Icon */}
              <div className="bg-blue-700 rounded px-2 py-1 flex items-center justify-center w-12 h-8">
                <FileText className="w-4 h-4 text-white" />
              </div>
            </div>
          </div>
        </nav>

        <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
          <p>&copy; 2023 Weakley County Fence. All rights reserved.</p>
          
          {/* Security & Privacy Notice */}
          <div className="mt-6 flex items-center justify-center gap-6 text-xs text-gray-500">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-green-500" />
              <span>SSL Secured Connection</span>
            </div>
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-green-500" />
              <span>Privacy Protected</span>
            </div>
          </div>
          <p className="mt-3 text-xs text-gray-600">
            Your information is encrypted and secure. We respect your privacy and will never share your personal data.
          </p>
        </div>
      </div>
    </footer>
  );
}