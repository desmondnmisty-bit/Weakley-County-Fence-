import { Award, Users, Clock, ThumbsUp, Shield, Heart, Star, CheckCircle, Check } from 'lucide-react';

const stats = [
  { icon: Award, value: '10', label: 'Years Experience', color: 'bg-[#355E3B]' },
  { icon: Users, value: '1,000+', label: 'Happy Customers', color: 'bg-black' },
  { icon: Clock, value: '2,500+', label: 'Projects Completed', color: 'bg-[#D2B48C]' },
];

export function About() {
  return (
    <section id="about" className="py-20 bg-gray-50" aria-labelledby="about-heading">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 id="about-heading" className="text-4xl mb-6">About Weakley County Fence</h2>
            
            {/* Credentials Badges */}
            <div className="flex flex-wrap gap-4 mb-6">
              {/* Meta Verified Badge */}
              <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <CheckCircle className="w-10 h-10 text-[#0081FB] fill-[#0081FB]" />
                  </div>
                  <div>
                    <div className="text-lg font-semibold text-gray-900">Meta Verified</div>
                    <div className="text-sm text-gray-600">Verified Business</div>
                  </div>
                </div>
              </div>

              {/* Google Verified Badge */}
              <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Check className="w-10 h-10 text-[#4285F4]" strokeWidth={3} />
                  </div>
                  <div>
                    <div className="text-lg font-semibold text-gray-900">Google Verified</div>
                    <div className="text-sm text-gray-600">Verified Business</div>
                  </div>
                </div>
              </div>

              {/* Angie's List Badge */}
              <div className="bg-white p-4 rounded-lg shadow-md border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <CheckCircle className="w-10 h-10 text-[#ff6f00] fill-[#ff6f00]" />
                  </div>
                  <div>
                    <div className="text-lg font-semibold text-gray-900">Angie's List</div>
                    <div className="text-sm text-gray-600">Listed Provider</div>
                  </div>
                </div>
              </div>
            </div>
            
            <p className="text-gray-600 mb-6">
              For over a decade, Weakley County Fence has been the trusted choice for professional fence installation and repair services in Sharon, Dresden, Union City, TN, and Fulton, KY. 
              Our commitment to quality craftsmanship and customer satisfaction has made us the premier fencing 
              contractor in the area.
            </p>
            
            <div className="bg-[#D2B48C]/20 border-l-4 border-[#355E3B] p-4 mb-6">
              <h3 className="text-xl mb-2">Locally Owned & Operated Small Business</h3>
              <p className="text-gray-700">
                Our owner, Nick, started as a fence installer and enjoyed what he did so much that he bought 
                the company in 2023. His passion for quality fencing and customer service drives everything we do 
                in Sharon, TN and surrounding communities.
              </p>
            </div>
            
            <p className="text-gray-600 mb-6">
              We specialize in residential and commercial fencing projects throughout Weakley County, using only premium quality 
              materials and proven installation techniques. Our experienced team takes pride in every fence project, 
              ensuring your fence not only looks great but stands the test of time.
            </p>
            <ul className="space-y-3 text-gray-600">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-600 rounded-full" aria-hidden="true"></span>
                Licensed and insured fence professionals in Tennessee
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-600 rounded-full" aria-hidden="true"></span>
                Free fence estimates and consultations
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-600 rounded-full" aria-hidden="true"></span>
                Competitive pricing with no hidden fees
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 bg-green-600 rounded-full" aria-hidden="true"></span>
                A+ BBB Rating for quality fence installation
              </li>
            </ul>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="bg-white p-8 rounded-lg shadow-md text-center border-t-4 border-[#355E3B]"
              >
                <div className={`w-12 h-12 ${stat.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-3xl mb-2">{stat.value}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
