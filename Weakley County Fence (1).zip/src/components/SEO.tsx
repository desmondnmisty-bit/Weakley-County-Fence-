import { useEffect } from 'react';

export function SEO() {
  useEffect(() => {
    // Set document title
    document.title = "Weakley County Fence | Professional Fencing Services in Sharon, TN | Free Estimates";
    
    // Create or update meta tags
    const metaTags = [
      { name: 'google-site-verification', content: 'QwIaCtggd4gd2LCqCfF1i9GC9Ltlilv4B8Ohc8l0RYc' },
      { name: 'google-site-verification', content: 'Za87TwvKAILks9jYnQSFq1xkPYATpXBaL7BZGLRYIQc' },
      { name: 'google-site-verification', content: 'ajtYZJzOHaeLVx5p4KpzOdz4y05laEtmTaH5dDmdkvI' },
      { name: 'description', content: 'Weakley County Fence offers professional fencing installation throughout Northwest Tennessee. Serving Weakley, Carroll, Henry, Gibson, Obion, Madison & Dyer Counties. A+ BBB rated. Free estimates. Call 731-456-2500.' },
      { name: 'keywords', content: 'fence installation Sharon TN, fencing company Dresden TN, fence contractor Union City TN, Martin TN fencing, McKenzie TN fence, Paris TN fence installation, Jackson TN fencing, Dyersburg TN fence, Trenton TN fence contractor, Huntingdon TN fencing, Weakley County fence, Carroll County fence, Henry County fence, Gibson County fence, Obion County fence, Madison County fence, Dyer County fence, wood fence, vinyl fence, chain link fence, privacy fence, fence builder, 38255 fencing, fence repair Dresden, commercial fencing Union City, residential fence Sharon, fence estimate Tennessee, licensed fence contractor, BBB rated fencing, fence cost calculator, fence installation near me, best fence company Northwest Tennessee, affordable fencing, fence replacement, gate installation, ornamental iron fence, farm fencing Tennessee, security fence installation, picket fence, fence maintenance, emergency fence repair, Milan TN fence, Humboldt TN fencing, Bradford TN fence, Puryear TN fence, Gleason TN fence contractor' },
      { name: 'author', content: 'Weakley County Fence' },
      { name: 'robots', content: 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1.0' },
      { name: 'googlebot', content: 'index, follow' },
      { name: 'bingbot', content: 'index, follow' },
      
      // Open Graph tags for social sharing
      { property: 'og:title', content: 'Weakley County Fence | Professional Fencing Services in Northwest Tennessee' },
      { property: 'og:description', content: 'A+ BBB rated fencing company serving 7 counties in Northwest TN. Weakley, Carroll, Henry, Gibson, Obion, Madison & Dyer Counties. Free estimates on all fence installations.' },
      { property: 'og:type', content: 'website' },
      { property: 'og:url', content: 'https://weakleycountyfence.com' },
      { property: 'og:locale', content: 'en_US' },
      { property: 'og:site_name', content: 'Weakley County Fence' },
      
      // Twitter Card tags
      { name: 'twitter:card', content: 'summary_large_image' },
      { name: 'twitter:title', content: 'Weakley County Fence | Professional Fencing Services' },
      { name: 'twitter:description', content: 'A+ BBB rated fencing company in Northwest Tennessee. Free estimates. Call 731-456-2500.' },
      
      // Local business tags
      { name: 'geo.region', content: 'US-TN' },
      { name: 'geo.placename', content: 'Sharon' },
      { name: 'geo.position', content: '36.2281;-88.8234' },
      { name: 'ICBM', content: '36.2281, -88.8234' },
      
      // Business category
      { name: 'category', content: 'Fence Installation, Fence Contractor, Home Improvement' },
      { name: 'coverage', content: 'Weakley County, Carroll County, Henry County, Gibson County, Obion County, Madison County, Dyer County, Northwest Tennessee' },
    ];

    metaTags.forEach(tag => {
      let element = document.querySelector(`meta[${tag.name ? 'name' : 'property'}="${tag.name || tag.property}"]`);
      
      if (!element) {
        element = document.createElement('meta');
        if (tag.name) {
          element.setAttribute('name', tag.name);
        } else if (tag.property) {
          element.setAttribute('property', tag.property);
        }
        document.head.appendChild(element);
      }
      
      element.setAttribute('content', tag.content);
    });

    // Add canonical link
    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = 'https://weakleycountyfence.com';

    // Add JSON-LD structured data for LocalBusiness
    const structuredData = {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      "name": "Weakley County Fence",
      "image": "https://weakleycountyfence.com/logo.png",
      "description": "Professional fence installation and repair services in Northwest Tennessee. Serving Weakley, Carroll, Henry, Gibson, Obion, Madison, and Dyer Counties with A+ BBB rating.",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "189 Dedham Rd",
        "addressLocality": "Sharon",
        "addressRegion": "TN",
        "postalCode": "38255",
        "addressCountry": "US"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 36.2281,
        "longitude": -88.8234
      },
      "url": "https://weakleycountyfence.com",
      "telephone": "+17314562500",
      "priceRange": "$$",
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          "opens": "09:00",
          "closes": "17:00"
        },
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": "Saturday",
          "opens": "09:00",
          "closes": "14:00"
        }
      ],
      "areaServed": [
        {
          "@type": "City",
          "name": "Sharon",
          "containedInPlace": {
            "@type": "AdministrativeArea",
            "name": "Weakley County"
          }
        },
        {
          "@type": "City",
          "name": "Dresden",
          "containedInPlace": {
            "@type": "AdministrativeArea",
            "name": "Weakley County"
          }
        },
        {
          "@type": "City",
          "name": "Martin",
          "containedInPlace": {
            "@type": "AdministrativeArea",
            "name": "Weakley County"
          }
        },
        {
          "@type": "City",
          "name": "Union City",
          "containedInPlace": {
            "@type": "AdministrativeArea",
            "name": "Obion County"
          }
        },
        {
          "@type": "City",
          "name": "McKenzie",
          "containedInPlace": {
            "@type": "AdministrativeArea",
            "name": "Carroll County"
          }
        },
        {
          "@type": "City",
          "name": "Paris",
          "containedInPlace": {
            "@type": "AdministrativeArea",
            "name": "Henry County"
          }
        },
        {
          "@type": "City",
          "name": "Jackson",
          "containedInPlace": {
            "@type": "AdministrativeArea",
            "name": "Madison County"
          }
        },
        {
          "@type": "City",
          "name": "Dyersburg",
          "containedInPlace": {
            "@type": "AdministrativeArea",
            "name": "Dyer County"
          }
        },
        {
          "@type": "City",
          "name": "Trenton",
          "containedInPlace": {
            "@type": "AdministrativeArea",
            "name": "Gibson County"
          }
        }
      ],
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Fencing Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Residential Fence Installation",
              "description": "Professional residential fence installation throughout Northwest Tennessee"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Commercial Fence Installation",
              "description": "Commercial and industrial fence installation services"
            }
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Fence Repair",
              "description": "Expert fence repair and maintenance services"
            }
          }
        ]
      },
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "5.0",
        "reviewCount": "150"
      },
      "slogan": "Where Fences Make Great Neighbors"
    };

    let scriptTag = document.querySelector('script[type="application/ld+json"]');
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.type = 'application/ld+json';
      document.head.appendChild(scriptTag);
    }
    scriptTag.textContent = JSON.stringify(structuredData);

  }, []);

  return null;
}