import { Home, Shield, Wrench } from 'lucide-react';

const services = [
  {
    icon: Home,
    title: 'Residential Fencing',
    description: 'Quality fences for homes including privacy, picket, decorative, wood, vinyl, aluminum, and ornamental iron options.',
    color: 'bg-[#355E3B]',
    keywords: 'residential fence installation, privacy fence, picket fence, backyard fence',
  },
  {
    icon: Shield,
    title: 'Commercial Fencing',
    description: 'Secure and durable fencing solutions including chain link, aluminum, ornamental iron for businesses and industrial properties.',
    color: 'bg-black',
    keywords: 'commercial fence, business fencing, industrial fence, security fence',
  },
  {
    icon: Wrench,
    title: 'Fence Repair',
    description: 'Expert repair services to restore and maintain your existing fence - all materials including aluminum and ornamental iron.',
    color: 'bg-[#D2B48C]',
    keywords: 'fence repair, fence maintenance, fence restoration',
  },
];

export function Services() {
  return (
    <section id="services" className="py-20 bg-gray-50" aria-labelledby="services-heading">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 id="services-heading" className="text-4xl mb-4">Our Fencing Services</h2>
          <p className="text-xl text-gray-600">
            Comprehensive fencing solutions throughout Weakley, Carroll, Henry, Gibson, Obion, Madison & Dyer Counties
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <article
              key={index}
              className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow border-t-4 border-[#355E3B]"
            >
              <div className={`w-16 h-16 ${service.color} rounded-lg flex items-center justify-center mb-4`} aria-hidden="true">
                <service.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl mb-3">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}