import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'Sarah Johnson',
    location: 'Dresden, TN',
    text: 'Excellent work! They installed a beautiful privacy fence in our backyard. The team was professional, punctual, and the quality exceeded our expectations.',
    rating: 5,
  },
  {
    name: 'Griffin Industries',
    location: 'Union City, TN',
    text: 'We needed a fence for our commercial property and they delivered perfectly. Great communication throughout the project and finished ahead of schedule.',
    rating: 5,
  },
  {
    name: 'Emily Rodriguez',
    location: 'Fulton, KY',
    text: 'From quote to completion, everything was smooth. Fair pricing, quality materials, and beautiful craftsmanship. Highly recommend!',
    rating: 5,
  },
  {
    name: 'Mike Patterson',
    location: 'Martin, TN',
    text: 'Best fence company in Northwest Tennessee! They installed our vinyl fence quickly and it looks amazing. A+ service all around.',
    rating: 5,
  },
  {
    name: 'Thompson Farm',
    location: 'McKenzie, TN',
    text: 'Needed farm fencing for our property in Carroll County. Weakley County Fence did an outstanding job at a great price. Very pleased!',
    rating: 5,
  },
  {
    name: 'Jennifer Williams',
    location: 'Paris, TN',
    text: 'Professional, courteous, and skilled. Our ornamental iron fence is stunning! Worth every penny. Highly recommend to anyone in Henry County.',
    rating: 5,
  },
];

export function Testimonials() {
  return (
    <section className="py-20 bg-white" aria-labelledby="testimonials-heading">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 id="testimonials-heading" className="text-4xl mb-4">Customer Reviews</h2>
          <p className="text-xl text-gray-600">
            Real feedback from satisfied customers in Dresden, Union City, and Fulton
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <article
              key={index}
              className="bg-gray-50 p-8 rounded-lg shadow-md"
              itemScope
              itemType="https://schema.org/Review"
            >
              <div className="flex gap-1 mb-4" aria-label={`${testimonial.rating} star rating`}>
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" aria-hidden="true" />
                ))}
                <meta itemProp="ratingValue" content={testimonial.rating.toString()} />
              </div>
              <p className="text-gray-700 mb-6 italic" itemProp="reviewBody">"{testimonial.text}"</p>
              <div itemProp="author" itemScope itemType="https://schema.org/Person">
                <div itemProp="name">{testimonial.name}</div>
                <div className="text-gray-500" itemProp="address">{testimonial.location}</div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}