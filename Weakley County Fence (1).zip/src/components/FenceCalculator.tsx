import { Calculator, Ruler } from 'lucide-react';
import { useState } from 'react';

const fenceRates = {
  wood: {
    '4ft': 22,
    '5ft': 27,
    '6ft': 32,
  },
  vinyl: {
    '4ft': 35,
    '5ft': 42,
    '6ft': 48,
  },
  chainlink: {
    '4ft': 12,
    '5ft': 15,
    '6ft': 18,
  },
  aluminum: {
    '4ft': 28,
    '5ft': 35,
    '6ft': 42,
  },
  ornamental: {
    '4ft': 38,
    '5ft': 45,
    '6ft': 52,
  },
};

export function FenceCalculator() {
  const [material, setMaterial] = useState<'wood' | 'vinyl' | 'chainlink' | 'aluminum' | 'ornamental'>('wood');
  const [height, setHeight] = useState<'4ft' | '5ft' | '6ft'>('6ft');
  const [linearFeet, setLinearFeet] = useState<string>('');
  const [total, setTotal] = useState<number | null>(null);

  const calculateTotal = () => {
    const feet = parseFloat(linearFeet);
    if (!isNaN(feet) && feet > 0) {
      const rate = fenceRates[material][height];
      setTotal(feet * rate);
    }
  };

  const materialLabels = {
    wood: 'Wood',
    vinyl: 'Vinyl',
    chainlink: 'Chain Link',
    aluminum: 'Aluminum',
    ornamental: 'Ornamental',
  };

  return (
    <section className="py-12 bg-gray-50" style={{ fontSize: '14px' }}>
      <div className="max-w-3xl mx-auto px-4">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-3">
            <Calculator className="w-8 h-8 text-[#355E3B]" />
            <h2 className="text-3xl">Project Cost Calculator</h2>
          </div>
          <p className="text-gray-600">
            Get an instant estimate for your fencing project
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-xl p-6 border-t-4 border-[#355E3B]">
          <div className="mb-6">
            <label className="block mb-3">
              <span className="flex items-center gap-2 mb-2 text-sm">
                Fence Material
              </span>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                {(['wood', 'vinyl', 'chainlink', 'aluminum', 'ornamental'] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMaterial(m)}
                    className={`py-2 px-3 rounded-lg border-2 transition-all text-sm ${
                      material === m
                        ? 'bg-[#355E3B] text-white border-[#355E3B]'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-[#355E3B]'
                    }`}
                  >
                    {materialLabels[m]}
                  </button>
                ))}
              </div>
            </label>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block mb-3">
                <span className="flex items-center gap-2 mb-2 text-sm">
                  <Ruler className="w-4 h-4 text-[#355E3B]" />
                  Fence Height
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {(['4ft', '5ft', '6ft'] as const).map((h) => (
                    <button
                      key={h}
                      type="button"
                      onClick={() => setHeight(h)}
                      className={`py-2 px-3 rounded-lg border-2 transition-all text-sm ${
                        height === h
                          ? 'bg-[#355E3B] text-white border-[#355E3B]'
                          : 'bg-white text-gray-700 border-gray-300 hover:border-[#355E3B]'
                      }`}
                    >
                      {h}
                    </button>
                  ))}
                </div>
              </label>
              
              <div className="mt-3 p-3 bg-[#D2B48C]/20 rounded-lg">
                <p className="text-xs text-gray-700">
                  Current Rate: <span className="font-bold text-[#355E3B]">${fenceRates[material][height]} per linear foot</span>
                </p>
                <p className="text-xs text-gray-600 mt-1">
                  {materialLabels[material]} - {height}
                </p>
              </div>
            </div>

            <div>
              <label className="block mb-2 text-sm">
                Linear Feet Needed
              </label>
              <input
                type="number"
                value={linearFeet}
                onChange={(e) => setLinearFeet(e.target.value)}
                placeholder="Enter linear feet"
                min="1"
                step="1"
                className="w-full px-3 py-2 border-2 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#355E3B] focus:border-[#355E3B] text-sm"
              />
              
              <button
                onClick={calculateTotal}
                className="w-full mt-3 py-3 bg-[#355E3B] text-white rounded-lg hover:bg-[#2a4a2e] transition-colors text-sm"
              >
                Calculate Estimate
              </button>
            </div>
          </div>

          {total !== null && (
            <div className="mt-6 p-4 bg-gradient-to-r from-[#355E3B] to-[#2a4a2e] text-white rounded-lg">
              <div className="text-center">
                <p className="text-sm mb-1">Estimated Project Cost</p>
                <p className="text-3xl mb-2">${total.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                <p className="text-xs opacity-90">
                  Based on {linearFeet} linear feet at ${fenceRates[material][height]}/ft for {height} {materialLabels[material].toLowerCase()} fence
                </p>
              </div>
            </div>
          )}

          <div className="mt-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
            <p className="text-xs text-gray-600 text-center">
              <strong>Note:</strong> This is an estimate only. Final pricing may vary based on terrain, 
              materials, gates, and site conditions. Contact us for a free detailed quote!
            </p>
          </div>

          <div className="mt-4 text-center">
            <a
              href="#contact"
              className="inline-block px-6 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors text-sm"
            >
              Get Free Detailed Quote
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}