import { MapPin, Navigation, Phone } from 'lucide-react';

export function MapLocation() {
  return (
    <section className="py-16 bg-white" aria-labelledby="location-heading">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 id="location-heading" className="text-4xl mb-4">Visit Our Location</h2>
          <p className="text-xl text-gray-600">
            Headquartered in Sharon, Tennessee - Serving 7 Counties in Northwest TN
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          {/* Map Embed */}
          <div className="w-full h-[400px] lg:h-[500px] rounded-lg overflow-hidden shadow-xl border-4 border-[#355E3B]">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3189.234567890123!2d-88.8234!3d36.2281!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzbCsDEzJzQxLjIiTiA4OMKwNDknMjQuMiJX!5e0!3m2!1sen!2sus!4v1234567890123!5m2!1sen!2sus&q=189+Dedham+Rd,+Sharon,+TN+38255"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Weakley County Fence Location - 189 Dedham Rd, Sharon, TN 38255"
            ></iframe>
          </div>

          {/* Location Details */}
          <div className="space-y-6">
            <div className="bg-[#355E3B] text-white p-8 rounded-lg shadow-lg">
              <div className="flex items-start gap-4 mb-6">
                <div className="bg-white/20 p-3 rounded-full">
                  <MapPin className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-2xl mb-2">Our Address</h3>
                  <address className="not-italic text-lg leading-relaxed">
                    189 Dedham Rd<br />
                    Sharon, TN 38255
                  </address>
                </div>
              </div>

              <div className="flex items-start gap-4 mb-6">
                <div className="bg-white/20 p-3 rounded-full">
                  <Phone className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-2xl mb-2">Call Us Today</h3>
                  <a 
                    href="tel:+17314562500" 
                    className="text-2xl hover:text-[#D2B48C] transition-colors"
                  >
                    731-456-2500
                  </a>
                  <p className="text-sm mt-1 opacity-90">Mon-Fri: 9am-5pm, Sat: 9am-2pm</p>
                </div>
              </div>

              <a
                href="https://www.google.com/maps/dir/?api=1&destination=189+Dedham+Rd,+Sharon,+TN+38255"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-3 w-full px-6 py-4 bg-[#D2B48C] text-black rounded-lg hover:bg-[#c4a67c] transition-colors"
              >
                <Navigation className="w-5 h-5" />
                <span className="font-semibold">Get Directions</span>
              </a>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg border-2 border-gray-200">
              <h3 className="text-xl mb-4">Service Area Coverage</h3>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#355E3B] rounded-full"></div>
                  <span>Weakley County</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#355E3B] rounded-full"></div>
                  <span>Carroll County</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#355E3B] rounded-full"></div>
                  <span>Henry County</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#355E3B] rounded-full"></div>
                  <span>Gibson County</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#355E3B] rounded-full"></div>
                  <span>Obion County</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#355E3B] rounded-full"></div>
                  <span>Madison County</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#355E3B] rounded-full"></div>
                  <span>Dyer County</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-[#355E3B] rounded-full"></div>
                  <span>Western KY</span>
                </div>
              </div>
              <p className="mt-4 text-xs text-gray-600 italic">
                We travel to customers throughout Northwest Tennessee. Call to confirm we serve your area!
              </p>
            </div>

            <div className="bg-[#D2B48C] p-6 rounded-lg">
              <h3 className="text-xl mb-3">Why Visit Us?</h3>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start gap-2">
                  <span className="text-[#355E3B] mt-1">✓</span>
                  <span>View fence material samples in person</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#355E3B] mt-1">✓</span>
                  <span>Discuss your project with our experts</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#355E3B] mt-1">✓</span>
                  <span>Get accurate measurements and quotes</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#355E3B] mt-1">✓</span>
                  <span>See our portfolio of completed projects</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
