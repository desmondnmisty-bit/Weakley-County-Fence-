import { MapPin, CheckCircle } from 'lucide-react';

export function ServiceAreas() {
  return (
    <section className="py-20 bg-gray-50" aria-labelledby="service-areas-heading">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 id="service-areas-heading" className="text-4xl mb-4">Fence Installation Service Areas</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional fencing services throughout Northwest Tennessee including Weakley, Carroll, Henry, Gibson, Obion, Madison, and Dyer Counties. Local, trusted, and A+ BBB rated.
          </p>
          <div className="mt-4 inline-block bg-[#355E3B] text-white px-6 py-2 rounded-full text-sm font-semibold">
            🚀 Adding New Service Areas Daily!
          </div>
        </div>

        <div className="bg-[#355E3B] text-white p-8 rounded-lg text-center mb-8">
          <h3 className="text-2xl mb-4">Serving All of Northwest Tennessee</h3>
          <p className="mb-4 max-w-4xl mx-auto">
            We also provide fence installation and repair services to communities throughout Northwest Tennessee and Western Kentucky. 
            From small towns to larger cities, Weakley County Fence brings professional fencing services to your location.
          </p>
          <div className="flex flex-wrap justify-center gap-3 text-sm">
            <span className="px-4 py-2 bg-white/20 rounded-full">Sharon, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Dresden, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Martin, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Union City, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">South Fulton, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">McKenzie, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Paris, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Jackson, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Dyersburg, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Trenton, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Huntingdon, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Milan, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Humboldt, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Palmersville, TN</span>
            <span className="px-4 py-2 bg-white/20 rounded-full">Fulton, KY</span>
          </div>
        </div>

        <div className="text-center">
          <a 
            href="#contact" 
            className="inline-block px-8 py-4 bg-[#355E3B] text-white rounded-lg hover:bg-[#2a4a2e] transition-colors text-lg"
            aria-label="Get free fence estimate in your area"
          >
            Get Free Estimate in Your Area
          </a>
          <p className="mt-4 text-gray-600">
            <a href="tel:+17314562500" className="text-[#355E3B] hover:underline font-semibold">Call 731-456-2500</a> or fill out our online form
          </p>
          <p className="mt-2 text-sm text-gray-500">
            Serving Weakley, Carroll, Henry, Gibson, Obion, Madison, and Dyer Counties
          </p>
        </div>
      </div>
    </section>
  );
}