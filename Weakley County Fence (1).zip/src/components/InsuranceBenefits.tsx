import { Shield, TrendingDown, Home, CheckCircle, Waves, Dog } from 'lucide-react';

export function InsuranceBenefits() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl mb-4">Privacy Fences & Homeowners Insurance</h2>
          <p className="text-xl text-gray-600">
            Installing a privacy fence can provide significant benefits for your homeowners insurance
          </p>
        </div>

        <div className="bg-[#D2B48C]/10 border-2 border-[#D2B48C] p-8 rounded-lg">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-16 h-16 bg-[#355E3B] rounded-lg flex items-center justify-center flex-shrink-0">
              <Home className="w-8 h-8 text-white" />
            </div>
            <div>
              <h3 className="text-2xl mb-4">Key Insurance Benefits</h3>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-start gap-3 bg-white p-4 rounded-lg border-l-4 border-[#355E3B]">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0">
                <Waves className="w-6 h-6 text-white" />
              </div>
              <div>
                <h4 className="mb-2">Pool Safety Requirements</h4>
                <p className="text-gray-600">
                  Many insurers require a 4-6 foot privacy fence around pools. Meeting this requirement 
                  can prevent policy cancellation and ensure full coverage.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 bg-white p-4 rounded-lg border-l-4 border-black">
              <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center flex-shrink-0">
                <Home className="w-6 h-6 text-white" />
              </div>
              <div>
                <h4 className="mb-2">Reduced Theft Risk</h4>
                <p className="text-gray-600">
                  Privacy fences deter burglars and reduce property theft by up to 25%, potentially 
                  lowering your property coverage costs.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 bg-white p-4 rounded-lg border-l-4 border-[#D2B48C]">
              <div className="w-12 h-12 bg-[#D2B48C] rounded-full flex items-center justify-center flex-shrink-0">
                <Dog className="w-6 h-6 text-white" />
              </div>
              <div>
                <h4 className="mb-2">Dog Bite Protection</h4>
                <p className="text-gray-600">
                  Homes with secure fencing see 60% fewer dog-related incidents. Some insurers require 
                  fencing for certain dog breeds to maintain coverage.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 bg-white p-4 rounded-lg border-l-4 border-[#355E3B]">
              <div className="w-12 h-12 bg-[#355E3B] rounded-full flex items-center justify-center flex-shrink-0">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <div>
                <h4 className="mb-2">Property Value Increase</h4>
                <p className="text-gray-600">
                  Privacy fences can increase property value by 5-10%, ensuring adequate coverage limits 
                  while improving your home's marketability.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-gray-600 italic">
            Contact your insurance provider to learn about specific discounts and requirements for fencing installations.
          </p>
        </div>
      </div>
    </section>
  );
}