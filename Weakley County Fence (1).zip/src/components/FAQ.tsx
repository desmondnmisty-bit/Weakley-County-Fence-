import { ChevronDown } from 'lucide-react';
import { useState } from 'react';

const faqs = [
  {
    question: 'How much does fence installation cost in Northwest Tennessee?',
    answer: 'Fence installation costs vary by material and project size. Wood fencing typically ranges from $15-30 per linear foot, vinyl fencing $20-40 per foot, and chain link $10-20 per foot. Contact us at 731-456-2500 for a free estimate tailored to your property in Weakley, Carroll, Henry, Gibson, Obion, Madison, or Dyer County.',
    keywords: 'fence installation cost Sharon TN, fence pricing Dresden, fence estimate Union City'
  },
  {
    question: 'What counties do you serve in Tennessee?',
    answer: 'We proudly serve all of Weakley County, Carroll County, Henry County, Gibson County, Obion County, Madison County, and Dyer County in Northwest Tennessee. Major cities include Sharon, Dresden, Martin, Union City, McKenzie, Paris, Jackson, Dyersburg, Trenton, and Huntingdon. We also serve communities in Western Kentucky.',
    keywords: 'fence installation Northwest Tennessee, service area Weakley County, fence contractor Tennessee'
  },
  {
    question: 'What types of fences do you install?',
    answer: 'We install all fence types including wood privacy fences, vinyl fencing, chain link fences, ornamental iron fencing, picket fences, farm fencing, and commercial security fencing. We serve residential and commercial properties throughout all 7 counties in Northwest Tennessee.',
    keywords: 'fence types Weakley County, wood fence Dresden TN, vinyl fence Union City'
  },
  {
    question: 'How long does fence installation take?',
    answer: 'Most residential fence installations in Sharon, Dresden, and surrounding areas take 2-5 days depending on project size and complexity. Commercial projects may take longer. We provide accurate timelines during your free consultation and work efficiently to minimize disruption.',
    keywords: 'fence installation timeline Sharon TN, how long fence install Dresden'
  },
  {
    question: 'Do you offer free estimates throughout Northwest Tennessee?',
    answer: 'Yes! We provide completely free, no-obligation estimates throughout our entire service area including all of Weakley, Carroll, Henry, Gibson, Obion, Madison, and Dyer Counties. Call 731-456-2500 or fill out our online form to schedule your free fence estimate today.',
    keywords: 'free fence estimate Union City TN, free quote Tennessee, fence consultation Dresden'
  },
  {
    question: 'Are you licensed and insured in Tennessee?',
    answer: 'Absolutely. Weakley County Fence is fully licensed, bonded, and insured throughout Tennessee. We maintain comprehensive liability coverage and are A+ BBB rated. Your property and investment are protected when you choose our professional fencing services.',
    keywords: 'licensed fence contractor Tennessee, insured fencing company Sharon TN, BBB rated'
  },
  {
    question: 'Do you repair existing fences?',
    answer: 'Yes, we offer expert fence repair services for all fence types throughout Northwest Tennessee. Whether you need panel replacement, post repair, gate fixes, or general maintenance, our experienced team can restore your fence in any of the 7 counties we serve.',
    keywords: 'fence repair Sharon TN, fence maintenance Dresden, gate repair Union City'
  },
  {
    question: 'How do I choose the right fence for my property?',
    answer: 'Our experts will help you select the perfect fence based on your needs - privacy, security, aesthetics, or pet containment. We consider your budget, property layout, and local regulations. Schedule a free consultation to discuss the best fencing solution for your property in Weakley, Carroll, Henry, Gibson, Obion, Madison, or Dyer County.',
    keywords: 'choosing fence type, best fence for privacy, residential fence options Sharon TN'
  }
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20 bg-white" aria-labelledby="faq-heading">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 id="faq-heading" className="text-4xl mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-gray-600">
            Common questions about fence installation in Northwest Tennessee
          </p>
        </div>

        <div 
          className="space-y-4"
          itemScope 
          itemType="https://schema.org/FAQPage"
        >
          {faqs.map((faq, index) => (
            <div 
              key={index}
              className="border border-gray-200 rounded-lg overflow-hidden"
              itemScope
              itemProp="mainEntity"
              itemType="https://schema.org/Question"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-6 py-4 text-left bg-gray-50 hover:bg-gray-100 transition-colors flex items-center justify-between gap-4"
                aria-expanded={openIndex === index}
                aria-controls={`faq-answer-${index}`}
              >
                <h3 className="font-semibold" itemProp="name">{faq.question}</h3>
                <ChevronDown 
                  className={`w-5 h-5 flex-shrink-0 transition-transform ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                  aria-hidden="true"
                />
              </button>
              <div
                id={`faq-answer-${index}`}
                className={`px-6 overflow-hidden transition-all ${
                  openIndex === index ? 'py-4 max-h-96' : 'max-h-0'
                }`}
                itemScope
                itemProp="acceptedAnswer"
                itemType="https://schema.org/Answer"
              >
                <p className="text-gray-700" itemProp="text">{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center p-8 bg-[#355E3B] text-white rounded-lg">
          <h3 className="text-2xl mb-4">Still Have Questions?</h3>
          <p className="mb-2">Our fence experts are ready to help with your project anywhere in our service area.</p>
          <p className="mb-6 text-sm opacity-90">We're expanding daily - call to check if we serve your location!</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="tel:+17314562500" 
              className="px-8 py-3 bg-white text-[#355E3B] rounded-lg hover:bg-gray-100 transition-colors inline-block"
            >
              Call 731-456-2500
            </a>
            <a 
              href="#contact" 
              className="px-8 py-3 bg-[#D2B48C] text-black rounded-lg hover:bg-[#c4a67c] transition-colors inline-block"
            >
              Request Free Estimate
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}