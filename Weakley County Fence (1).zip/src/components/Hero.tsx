import { Phone, Mail } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import logoImage from 'figma:asset/af8a5adf34dc1fea72ca1bdf99b8493e88696d13.png';

export function Hero() {
  return (
    <header className="relative h-screen">
      <ImageWithFallback
        src="https://images.unsplash.com/photo-1759455442052-258d0daf08cf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b29kZW4lMjBmZW5jZSUyMHJlc2lkZW50aWFsfGVufDF8fHx8MTc2NDYxNzEzNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
        alt="Professional residential wooden fence installation in Sharon, Tennessee - Weakley County Fence"
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-black bg-opacity-50" aria-hidden="true" />
      
      <div className="absolute inset-0 flex flex-col justify-center items-center text-white px-4">
        <img 
          src={logoImage} 
          alt="Weakley County Fence - Professional Fencing Company in Sharon, TN" 
          className="w-full max-w-md mb-8"
        />
        <h1 className="text-xl md:text-2xl text-center mb-12 max-w-2xl italic font-bold">
          Where Fences Make Great Neighbors
        </h1>
        
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <a
            href="#contact"
            className="px-8 py-4 bg-[#355E3B] hover:bg-[#2a4a2e] transition-colors rounded-lg"
            aria-label="Get a free fence installation estimate"
          >
            Get Free Estimate
          </a>
          <a
            href="tel:+17314562500"
            className="px-8 py-4 bg-[#D2B48C] hover:bg-[#c4a67c] text-black transition-colors rounded-lg"
            aria-label="Call for fence installation services"
          >
            Call 731-456-2500
          </a>
        </div>
        
        <p className="text-sm md:text-base text-center max-w-2xl">
          Professional Fence Installation & Repair | Serving 7 Counties in Northwest Tennessee
        </p>
      </div>
    </header>
  );
}