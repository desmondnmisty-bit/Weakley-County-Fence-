import { Phone, Calculator } from 'lucide-react';

export function CTABanner() {
  return (
    <section className="bg-gradient-to-r from-[#355E3B] to-[#2a4a2e] py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="text-white">
            <h2 className="text-3xl mb-4">Ready to Transform Your Property?</h2>
            <p className="text-lg mb-2">
              Get your FREE, no-obligation fence estimate today!
            </p>
            <p className="text-sm opacity-90">
              ✓ A+ BBB Rated • ✓ Licensed & Insured • ✓ Local Family-Owned Business
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="tel:+17314562500"
              className="flex items-center justify-center gap-3 px-6 py-4 bg-white text-[#355E3B] rounded-lg hover:bg-gray-100 transition-colors flex-1"
            >
              <Phone className="w-5 h-5" />
              <div className="text-left">
                <div className="text-xs uppercase tracking-wide">Call Now</div>
                <div className="font-bold">731-456-2500</div>
              </div>
            </a>
            
            <a
              href="#contact"
              className="flex items-center justify-center gap-3 px-6 py-4 bg-[#D2B48C] text-black rounded-lg hover:bg-[#c4a67c] transition-colors flex-1"
            >
              <Calculator className="w-5 h-5" />
              <div className="text-left">
                <div className="text-xs uppercase tracking-wide">Online</div>
                <div className="font-bold">Get Estimate</div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
