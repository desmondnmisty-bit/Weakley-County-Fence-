import { Construction } from 'lucide-react';

export function Gallery() {
  return (
    <section id="gallery" className="py-20 bg-gray-50" aria-labelledby="gallery-heading">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h2 id="gallery-heading" className="text-4xl mb-4">Fence Installation Gallery</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Browse our completed fence projects in Sharon, Dresden, Union City, TN and Fulton, KY
          </p>
        </div>

        {/* Under Construction */}
        <div className="max-w-md mx-auto text-center">
          <div className="bg-white rounded-2xl shadow-lg p-12 border-4 border-dashed border-[#8B4513]">
            <div className="inline-flex items-center justify-center w-24 h-24 bg-[#F4A460]/10 rounded-full mb-6">
              <Construction className="w-12 h-12 text-[#8B4513]" strokeWidth={2} />
            </div>
            <h3 className="text-2xl mb-3 text-[#2D5016]">Gallery Coming Soon!</h3>
            <p className="text-gray-600 mb-4">
              We're currently updating our photo gallery with beautiful new fence installation projects.
            </p>
            <p className="text-sm text-gray-500">
              Check back soon to see our latest work!
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}