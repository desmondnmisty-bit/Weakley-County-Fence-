import { Hero } from "./components/Hero";
import { Services } from "./components/Services";
import { Gallery } from "./components/Gallery";
import { InsuranceBenefits } from "./components/InsuranceBenefits";
import { FenceCalculator } from "./components/FenceCalculator";
import { CTABanner } from "./components/CTABanner";
import { About } from "./components/About";
import { ServiceAreas } from "./components/ServiceAreas";
import { ExpandingCoverage } from "./components/ExpandingCoverage";
import { MapLocation } from "./components/MapLocation";
import { FAQ } from "./components/FAQ";
import { Testimonials } from "./components/Testimonials";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";
import { SEO } from "./components/SEO";

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <SEO />
      <Hero />
      <Services />
      <Gallery />
      <InsuranceBenefits />
      <FenceCalculator />
      <CTABanner />
      <About />
      <ServiceAreas />
      <ExpandingCoverage />
      <MapLocation />
      <FAQ />
      <Testimonials />
      <Contact />
      <Footer />
    </div>
  );
}